# Weekly analytics: dev-decline

Both sources report lower weekly activity, while each measures a distinct population. Search Console shows fewer clicks alongside worse average position; PostHog records fewer sessions and conversions. These aggregate comparisons identify where to investigate, not why the changes occurred.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 1535 | 1074 | -461 | -30.032573 | count | ok |
| impressions | 30691 | 28645 | -2046 | -6.666449 | count | ok |
| position | 5.753 | 7.053 | 1.3 | 22.596906 | position | ok |
| ctr | 0.050015 | 0.037493 | -0.012521 | -25.035075 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 2445 | 1956 | -489 | -20 | count | ok |
| users | 2140 | 1742 | -398 | -18.598131 | count | ok |
| conversions | 122 | 98 | -24 | -19.672131 | count | ok |
| conversion_rate | 0.049898 | 0.050102 | 0.000204 | 0.409834 | ratio | ok |

## Findings

- Search Console clicks fell week over week, the largest absolute acquisition change in this report; investigate which queries and pages account for the loss. Evidence: search_console.clicks.wow_pct.
- Average Search Console position worsened week over week (a higher position value); inspect query- and page-level ranking changes. Evidence: search_console.position.wow_pct.
- PostHog conversions declined week over week; compare the funnel and traffic mix before attributing the change to conversion performance. Evidence: posthog.conversions.wow_pct.

## Limitations

- This report uses a synthetic development fixture, not live customer data; validate operational decisions against approved production data. (synthetic_data)
- Search Console clicks and PostHog sessions represent different populations and measurement systems; do not substitute, add, or equate them. (source_distinction)

## Next checks

- In Search Console, segment clicks, impressions, CTR, and position by query and landing page; compare the largest losing segments with the prior week.
- In PostHog, inspect acquisition/referrer and landing-page segments, then compare funnel steps and conversion tracking for the two periods.
- Check whether the observed week-over-week shifts persist in subsequent complete weeks before treating them as a sustained trend.
