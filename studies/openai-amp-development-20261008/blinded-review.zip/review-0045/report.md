# Weekly analytics: dev-growth

Both sources show higher weekly activity with complete seven-day coverage. Search Console impressions and clicks rose at similar rates, while PostHog conversions increased alongside sessions; the aggregate data do not establish why these movements occurred. Search Console clicks and PostHog sessions describe distinct populations and are reported separately.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 986 | 1232 | 246 | 24.94929 | count | ok |
| impressions | 19716 | 24646 | 4930 | 25.005072 | count | ok |
| position | 6.6 | 6.3 | -0.3 | -4.545455 | position | ok |
| ctr | 0.05001 | 0.049988 | -0.000022 | -0.044623 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1775 | 2130 | 355 | 20 | count | ok |
| users | 1479 | 1785 | 306 | 20.689655 | count | ok |
| conversions | 89 | 107 | 18 | 20.224719 | count | ok |
| conversion_rate | 0.050141 | 0.050235 | 0.000094 | 0.187266 | ratio | ok |

## Findings

- Search Console impressions increased week over week, the largest supported percentage gain among the reported activity counts. Evidence: search_console.impressions.wow_pct.
- Search Console clicks also increased week over week, keeping pace with the higher impression volume. Evidence: search_console.clicks.wow_pct.
- PostHog-recorded conversions increased week over week; aggregate counts alone do not explain the cause. Evidence: posthog.conversions.wow_pct.

## Limitations

- This report uses a synthetic development fixture, not live customer data; treat the results as illustrative rather than production performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations and must not be equated, substituted, or added together. (source_distinction)

## Next checks

- Compare Search Console query, page, and device breakdowns across the same dates to see where impressions and clicks changed.
- Inspect PostHog acquisition and landing-page segments, and verify the conversion event definition and instrumentation across both weeks.
- Review the next complete seven-day periods before treating these aggregate week-over-week movements as a sustained trend.
