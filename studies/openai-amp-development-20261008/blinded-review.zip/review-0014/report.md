# Weekly analytics: dev-retry

Synthetic weekly analytics report. Changes describe observed source metrics; causal explanations require additional evidence.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 821 | 1067 | 246 | 29.963459 | count | ok |
| impressions | 16423 | 18989 | 2566 | 15.624429 | count | ok |
| position | 7.935 | 7.235 | -0.7 | -8.821676 | position | ok |
| ctr | 0.049991 | 0.05619 | 0.0062 | 12.401385 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1404 | 1474 | 70 | 4.985755 | count | ok |
| users | 1203 | 1244 | 41 | 3.408146 | count | ok |
| conversions | 56 | 63 | 7 | 12.5 | count | ok |
| conversion_rate | 0.039886 | 0.042741 | 0.002855 | 7.157394 | ratio | ok |

## Findings

- search_console clicks increased from 821 to 1067 (29.963459% week over week). Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.wow_pct.

## Limitations

- This report uses synthetic fixture data only. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations and are not interchangeable. (source_distinction)

## Next checks

- Check source collection coverage before drawing conclusions.
- Segment each source by page and acquisition channel before proposing causes.
