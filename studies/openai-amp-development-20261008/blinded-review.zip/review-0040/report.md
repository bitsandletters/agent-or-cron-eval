# Weekly analytics: dev-decline

Both sources have complete weekly coverage. Search Console shows fewer clicks, lower CTR, fewer impressions, and a worsening average position. Separately, PostHog shows fewer sessions, users, and conversions, with a nearly unchanged conversion rate. Prioritize investigating the search performance decline and the loss of session volume; these aggregates do not establish causes or connect the two populations.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 1535 | 1074 | -461 | -30.032573 | count | ok |
| impressions | 30691 | 28645 | -2046 | -6.666449 | count | ok |
| position | 5.753 | 7.053 | 1.3 | 22.596906 | position | ok |
| ctr | 0.050015 | 0.037493 | -0.012521 | -25.035075 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 2445 | 1956 | -489 | -20 | count | ok |
| users | 2140 | 1742 | -398 | -18.598131 | count | ok |
| conversions | 122 | 98 | -24 | -19.672131 | count | ok |
| conversion_rate | 0.049898 | 0.050102 | 0.000204 | 0.409834 | ratio | ok |

## Findings

- Search Console clicks declined from 1535 to 1074, a change of -461 clicks (-30.032573% week over week). This is a material loss of search click volume; inspect affected queries and pages before attributing a cause. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- Search Console CTR fell from 0.050014662 to 0.037493454 as fractions of impressions (-25.035075% week over week). The decline merits query- and page-level investigation of click yield, but aggregate CTR cannot distinguish changes within segments from changes in their mix. Evidence: search_console.ctr.previous, search_console.ctr.current, search_console.ctr.wow_pct.
- PostHog conversions declined from 122 to 98, a change of -24 conversions (-19.672131% week over week). Investigate which acquisition and landing-page segments lost conversions; this count alone does not demonstrate a conversion-efficiency problem. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.

## Limitations

- All inputs are synthetic fixture data, not live customer observations; this report supports evaluation rather than conclusions about a real business. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations. Their totals must not be added, substituted, equated, or treated as a connected funnel without additional attribution evidence. (source_distinction)
- Complete weekly coverage permits the reported comparisons, but weekly aggregates provide no query, page, channel, device, daily, or cohort breakdowns. They cannot identify causes, isolate mix effects, establish statistical significance, or show whether declines persist. (aggregate_only)

## Next checks

- Request Search Console query and page breakdowns for the same periods, then segment by device and country. Identify the largest click losses and compare impressions, CTR, and position within matched segments to separate visibility changes from click-yield and mix changes.
- Request PostHog sessions, conversions, and conversion rates by acquisition channel and landing page for the same periods. Locate the largest volume losses and check whether conversion rates changed within those segments despite the nearly unchanged aggregate rate.
- Inspect daily source-specific trends and adjacent complete weeks to assess persistence; check tracking definitions and deployment records before proposing explanations. Only relate search clicks to PostHog activity after validating attribution and population coverage.
