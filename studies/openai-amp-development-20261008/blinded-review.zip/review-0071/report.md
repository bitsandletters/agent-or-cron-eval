# Weekly analytics: dev-quiet

Across two complete weeks, Search Console clicks rose alongside higher impressions and a modest improvement in average position. PostHog sessions and conversions also increased, while conversion rate was effectively unchanged. These are source-specific observations, not evidence that search clicks equal or caused product sessions or conversions.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 896 | 932 | 36 | 4.017857 | count | ok |
| impressions | 17923 | 18420 | 497 | 2.772973 | count | ok |
| position | 6.833 | 6.633 | -0.2 | -2.926972 | position | ok |
| ctr | 0.049992 | 0.050597 | 0.000606 | 1.211295 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1679 | 1729 | 50 | 2.977963 | count | ok |
| users | 1417 | 1448 | 31 | 2.187721 | count | ok |
| conversions | 67 | 69 | 2 | 2.985075 | count | ok |
| conversion_rate | 0.039905 | 0.039907 | 0.000003 | 0.006906 | ratio | ok |

## Findings

- Search Console clicks increased 4.017857% week over week, the clearest top-of-funnel gain in the available search data. Evidence: search_console.clicks.wow_pct.
- Average Search Console position improved (lower is better); its week-over-week relative change was -2.926972%. Evidence: search_console.position.wow_pct.
- PostHog conversion rate was essentially flat, with a week-over-week relative change of 0.006906%; the higher conversion count therefore came with more sessions rather than a material rate shift in these aggregates. Evidence: posthog.conversion_rate.wow_pct.

## Limitations

- The fixture is synthetic and should not be treated as a live business performance result. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations and must not be substituted, added, or treated as equivalent; aggregate weekly counts do not establish attribution or cause. (source_distinction)

## Next checks

- Break Search Console clicks and impressions down by query, page, device, and country to identify where the search gains occurred.
- Review PostHog acquisition-source and landing-page cohorts alongside conversions and conversion rate to assess whether traffic mix changed; do not assume search clicks correspond to sessions.
- Check subsequent complete weeks and confirm the same metric definitions and instrumentation before treating these modest movements as a trend.
