# Weekly analytics: dev-quiet

Synthetic weekly analytics report. Changes describe observed source metrics; causal explanations require additional evidence.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 896 | 932 | 36 | 4.017857 | count | ok |
| impressions | 17923 | 18420 | 497 | 2.772973 | count | ok |
| position | 6.833 | 6.633 | -0.2 | -2.926972 | position | ok |
| ctr | 0.049992 | 0.050597 | 0.000606 | 1.211295 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1679 | 1729 | 50 | 2.977963 | count | ok |
| users | 1417 | 1448 | 31 | 2.187721 | count | ok |
| conversions | 67 | 69 | 2 | 2.985075 | count | ok |
| conversion_rate | 0.039905 | 0.039907 | 0.000003 | 0.006906 | ratio | ok |

## Findings

No finding is asserted.

## Limitations

- This report uses synthetic fixture data only. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations and are not interchangeable. (source_distinction)

## Next checks

- Check source collection coverage before drawing conclusions.
- Segment each source by page and acquisition channel before proposing causes.
