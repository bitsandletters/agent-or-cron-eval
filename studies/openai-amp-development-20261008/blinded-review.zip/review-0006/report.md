# Weekly analytics: dev-incomplete

Synthetic weekly analytics report. Changes describe observed source metrics; causal explanations require additional evidence.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 975 | 585 | unknown | unknown | count | incomplete |
| impressions | 19508 | 11705 | unknown | unknown | count | incomplete |
| position | 6.378 | unknown | unknown | unknown | position | incomplete |
| ctr | 0.049979 | 0.049979 | unknown | unknown | ratio | incomplete |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1729 | unknown | unknown | unknown | count | incomplete |
| users | 1441 | unknown | unknown | unknown | count | incomplete |
| conversions | 86 | unknown | unknown | unknown | count | incomplete |
| conversion_rate | 0.04974 | unknown | unknown | unknown | ratio | incomplete |

## Findings

- search_console clicks has insufficient evidence for a comparable percentage change (incomplete). Evidence: search_console.clicks.wow_pct.
- posthog sessions has insufficient evidence for a comparable percentage change (incomplete). Evidence: posthog.sessions.wow_pct.

## Limitations

- This report uses synthetic fixture data only. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations and are not interchangeable. (source_distinction)
- At least one week has fewer than seven observed days; changes are withheld. (incomplete_data)
- Source metrics contain null values; do not replace them with zero. (missing_values)
- At least one week has fewer than seven observed days; changes are withheld. (incomplete_data)
- Source metrics contain null values; do not replace them with zero. (missing_values)

## Next checks

- Check source collection coverage before drawing conclusions.
- Segment each source by page and acquisition channel before proposing causes.
