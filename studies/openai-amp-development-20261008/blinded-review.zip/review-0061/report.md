# Weekly analytics: dev-quiet

Both sources have full seven-day coverage in both weeks. PostHog conversions and sessions increased modestly, while conversion rate was nearly unchanged. Separately, Search Console clicks and impressions increased, CTR edged up, and average position decreased, a favorable direction. These weekly aggregates do not establish causes or a sustained trend.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 896 | 932 | 36 | 4.017857 | count | ok |
| impressions | 17923 | 18420 | 497 | 2.772973 | count | ok |
| position | 6.833 | 6.633 | -0.2 | -2.926972 | position | ok |
| ctr | 0.049992 | 0.050597 | 0.000606 | 1.211295 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1679 | 1729 | 50 | 2.977963 | count | ok |
| users | 1417 | 1448 | 31 | 2.187721 | count | ok |
| conversions | 67 | 69 | 2 | 2.985075 | count | ok |
| conversion_rate | 0.039905 | 0.039907 | 0.000003 | 0.006906 | ratio | ok |

## Findings

- PostHog conversions rose from 67 to 69, an increase of 2 conversions (2.985075% week over week). This is a modest absolute gain; the aggregate alone does not establish a meaningful improvement in conversion performance. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.
- Search Console clicks increased from 896 to 932, a gain of 36 clicks (4.017857% week over week). This supports a modest increase in measured search click volume, not a claim about site sessions or downstream conversions. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- PostHog conversion rate was nearly unchanged: 0.039904705 previously and 0.039907461 currently, expressed as fractions, with a relative increase of 0.006906%. The observed rate change is too small to justify treating this week as evidence of a substantial conversion-efficiency gain. Evidence: posthog.conversion_rate.previous, posthog.conversion_rate.current, posthog.conversion_rate.wow_pct.

## Limitations

- All inputs are synthetic fixtures, not live customer data; this report does not describe a real business. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations. They cannot be added, equated, or used to attribute PostHog conversions to search traffic. (source_distinction)
- Only adjacent weekly aggregates are supplied. Full observed-day coverage makes arithmetic comparisons available, but does not establish statistical significance, within-week variation, causes, or a sustained trend. No segment, funnel, attribution, or historical baseline data are available. (aggregate_only)

## Next checks

- Review additional fully observed weeks of PostHog sessions, conversions, and conversion rate before treating the small conversion increase as a persistent improvement; retain consistent conversion definitions and inspect event instrumentation.
- Break down Search Console clicks, impressions, CTR, and position by query, page, device, and country to locate the contributions to the click increase and check whether the aggregate position change reflects a shift in query mix.
- Inspect PostHog conversion funnels and rates by acquisition channel and landing page to test for segment-level gains or losses hidden by the nearly unchanged aggregate rate. Any search-to-conversion attribution requires compatible tracking and definitions, not matching the two sources' weekly totals.
