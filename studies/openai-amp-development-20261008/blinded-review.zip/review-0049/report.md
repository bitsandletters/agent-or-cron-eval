# Weekly analytics: dev-retry

Both sources have complete weekly coverage. Search Console clicks and impressions show the largest relative increases among the reported KPIs. Separately, PostHog conversions increased. These aggregate observations do not establish causes or connect search clicks to product conversions.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 821 | 1067 | 246 | 29.963459 | count | ok |
| impressions | 16423 | 18989 | 2566 | 15.624429 | count | ok |
| position | 7.935 | 7.235 | -0.7 | -8.821676 | position | ok |
| ctr | 0.049991 | 0.05619 | 0.0062 | 12.401385 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1404 | 1474 | 70 | 4.985755 | count | ok |
| users | 1203 | 1244 | 41 | 3.408146 | count | ok |
| conversions | 56 | 63 | 7 | 12.5 | count | ok |
| conversion_rate | 0.039886 | 0.042741 | 0.002855 | 7.157394 | ratio | ok |

## Findings

- Search Console clicks increased from 821 to 1067, a gain of 246 (+29.963459% week over week), the largest relative change among the reported KPIs. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- Search Console impressions increased from 16423 to 18989, a gain of 2566 (+15.624429% week over week). The aggregate does not identify which queries or pages contributed. Evidence: search_console.impressions.previous, search_console.impressions.current, search_console.impressions.absolute_change, search_console.impressions.wow_pct.
- PostHog conversions increased from 56 to 63, a gain of 7 (+12.5% week over week). This is an observed increase, not evidence of a sustained trend or a causal link to search activity. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.

## Limitations

- All inputs are synthetic fixtures, not live customer data; results describe only this supplied packet. (synthetic_data)
- Search Console clicks and PostHog sessions represent different populations and cannot be substituted, added, or equated. No cross-source attribution is available. (source_distinction)
- Complete weekly coverage supports the reported arithmetic, but aggregate weekly totals cannot establish causes, statistical significance, or persistence. No calculation warnings were emitted. (aggregate_scope)

## Next checks

- Validate Search Console daily totals against the weekly aggregates and inspect query and page breakdowns for contributions to the click and impression increases.
- Validate the PostHog conversion event definition and deduplication, then examine daily conversion counts and session cohorts to assess the observed increase.
- Compare additional complete weeks before treating either source's observed movement as a sustained trend; retain separate source populations and verify reporting timezone boundaries.
