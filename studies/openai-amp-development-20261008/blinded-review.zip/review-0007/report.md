# Weekly analytics: dev-decline

Synthetic weekly analytics report. Changes describe observed source metrics; causal explanations require additional evidence.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 1535 | 1074 | -461 | -30.032573 | count | ok |
| impressions | 30691 | 28645 | -2046 | -6.666449 | count | ok |
| position | 5.753 | 7.053 | 1.3 | 22.596906 | position | ok |
| ctr | 0.050015 | 0.037493 | -0.012521 | -25.035075 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 2445 | 1956 | -489 | -20 | count | ok |
| users | 2140 | 1742 | -398 | -18.598131 | count | ok |
| conversions | 122 | 98 | -24 | -19.672131 | count | ok |
| conversion_rate | 0.049898 | 0.050102 | 0.000204 | 0.409834 | ratio | ok |

## Findings

- search_console clicks decreased from 1535 to 1074 (-30.032573% week over week). Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.wow_pct.
- posthog sessions decreased from 2445 to 1956 (-20% week over week). Evidence: posthog.sessions.previous, posthog.sessions.current, posthog.sessions.wow_pct.

## Limitations

- This report uses synthetic fixture data only. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations and are not interchangeable. (source_distinction)

## Next checks

- Check source collection coverage before drawing conclusions.
- Segment each source by page and acquisition channel before proposing causes.
