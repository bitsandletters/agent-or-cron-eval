# Weekly analytics: dev-quiet

Both sources have complete weekly coverage. Search Console clicks increased modestly, while PostHog conversions and sessions also rose modestly within their separate population. PostHog conversion rate was nearly unchanged. These aggregate observations do not establish causes or statistical significance.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 896 | 932 | 36 | 4.017857 | count | ok |
| impressions | 17923 | 18420 | 497 | 2.772973 | count | ok |
| position | 6.833 | 6.633 | -0.2 | -2.926972 | position | ok |
| ctr | 0.049992 | 0.050597 | 0.000606 | 1.211295 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1679 | 1729 | 50 | 2.977963 | count | ok |
| users | 1417 | 1448 | 31 | 2.187721 | count | ok |
| conversions | 67 | 69 | 2 | 2.985075 | count | ok |
| conversion_rate | 0.039905 | 0.039907 | 0.000003 | 0.006906 | ratio | ok |

## Findings

- Search Console clicks rose from 896 to 932, an increase of 36 (+4.017857% week over week). This is the largest relative KPI movement in the report, but remains a modest observed gain rather than evidence of a sustained trend. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- PostHog conversions increased from 67 to 69, a gain of 2 (+2.985075% week over week). The absolute gain is small; this observation alone does not establish a meaningful improvement in conversion performance. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.
- PostHog sessions increased from 1679 to 1729, a gain of 50 (+2.977963% week over week). This is a modest increase in measured site activity, not a measure of search clicks or evidence of a particular acquisition cause. Evidence: posthog.sessions.previous, posthog.sessions.current, posthog.sessions.absolute_change, posthog.sessions.wow_pct.

## Limitations

- All observations come from the supplied synthetic fixture, not live customer data; they do not describe actual business performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations and must not be added, substituted, or equated. CTR uses clicks divided by impressions; conversion rate uses conversions divided by sessions. (source_distinction)
- Coverage is complete and the calculation tool emitted no warnings, but weekly aggregates do not identify causes, establish statistical significance, or show whether modest changes persist. (aggregate_scope)

## Next checks

- Compare additional complete weeks and daily patterns to assess whether the modest changes persist rather than treating this comparison as a trend.
- Request Search Console query and landing-page breakdowns to locate the click changes, keeping analysis within the Search Console population.
- Validate that PostHog session and conversion event definitions and instrumentation were unchanged, then inspect channel and funnel breakdowns to assess conversion performance without assuming a cause.
