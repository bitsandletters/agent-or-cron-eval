# Weekly analytics: dev-retry

Both sources have complete seven-day coverage for both weeks. Search Console measures increased, while PostHog sessions, users, conversions, and conversion rate also increased; the source populations remain distinct, and aggregate weekly counts do not establish causes.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 821 | 1067 | 246 | 29.963459 | count | ok |
| impressions | 16423 | 18989 | 2566 | 15.624429 | count | ok |
| position | 7.935 | 7.235 | -0.7 | -8.821676 | position | ok |
| ctr | 0.049991 | 0.05619 | 0.0062 | 12.401385 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1404 | 1474 | 70 | 4.985755 | count | ok |
| users | 1203 | 1244 | 41 | 3.408146 | count | ok |
| conversions | 56 | 63 | 7 | 12.5 | count | ok |
| conversion_rate | 0.039886 | 0.042741 | 0.002855 | 7.157394 | ratio | ok |

## Findings

- Search Console clicks rose 29.963459% week over week; validate the gain by examining query and landing-page segments. Evidence: search_console.clicks.wow_pct.
- Search Console CTR rose 12.401385% week over week; inspect query-level impressions and clicks to see where the change is concentrated. Evidence: search_console.ctr.wow_pct.
- PostHog conversion rate rose 7.157394% week over week; validate the rate against conversion definitions and relevant funnel segments. Evidence: posthog.conversion_rate.wow_pct.

## Limitations

- This report uses a supplied synthetic fixture; its metrics should not be treated as live customer or production measurements. (synthetic_data)
- Search Console clicks and PostHog sessions represent different populations and are reported separately; they must not be substituted, added, or equated. (source_distinction)

## Next checks

- In Search Console, compare query and landing-page segments for clicks, impressions, CTR, and average position across the two weeks.
- In PostHog, validate the conversion event definition and inspect funnel and segment breakdowns for conversions and conversion rate.
- Confirm source reporting settings and date boundaries remain consistent for future weekly comparisons.
