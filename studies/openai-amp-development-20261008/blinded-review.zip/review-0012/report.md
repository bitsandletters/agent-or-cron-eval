# Weekly analytics: dev-growth

Both sources have complete weekly coverage. Search Console impressions and clicks increased by roughly a quarter, while PostHog users, sessions, and conversions increased by roughly a fifth. CTR and conversion rate changed little relative to the volume increases. These are separate source-specific observations, not a reconciled acquisition funnel or evidence of a shared cause.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 986 | 1232 | 246 | 24.94929 | count | ok |
| impressions | 19716 | 24646 | 4930 | 25.005072 | count | ok |
| position | 6.6 | 6.3 | -0.3 | -4.545455 | position | ok |
| ctr | 0.05001 | 0.049988 | -0.000022 | -0.044623 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1775 | 2130 | 355 | 20 | count | ok |
| users | 1479 | 1785 | 306 | 20.689655 | count | ok |
| conversions | 89 | 107 | 18 | 20.224719 | count | ok |
| conversion_rate | 0.050141 | 0.050235 | 0.000094 | 0.187266 | ratio | ok |

## Findings

- Search Console impressions increased from 19716 to 24646, a gain of 4930 (+25.005072% week over week), the largest supported percentage increase among the reported KPIs. This indicates more search-result exposure; the aggregate does not identify which queries or pages contributed. Evidence: search_console.impressions.previous, search_console.impressions.current, search_console.impressions.absolute_change, search_console.impressions.wow_pct.
- Search Console clicks increased from 986 to 1232, a gain of 246 (+24.94929% week over week). This is a substantial increase in recorded search clicks, but it does not establish an equivalent increase in PostHog sessions or identify the cause. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- PostHog users increased from 1479 to 1785, a gain of 306 (+20.689655% week over week), the largest percentage increase within PostHog. The weekly aggregate does not distinguish new users from returning users or show which acquisition channels contributed. Evidence: posthog.users.previous, posthog.users.current, posthog.users.absolute_change, posthog.users.wow_pct.

## Limitations

- This report uses only the supplied synthetic fixture and makes no claims about live customer performance. Both sources report seven observed days in each week; the calculation tool emitted no warnings. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations. They are reported separately and must not be added, substituted, or equated; the packet supplies no attribution bridge between them. (source_distinction)
- Weekly aggregates do not establish causes, channel contribution, user mix, or statistical significance. Complete day coverage supports weekly comparisons but does not independently verify tracking accuracy. CTR and conversion_rate are fractions; wow_pct is a percentage, not a percentage-point change. (aggregate_only)

## Next checks

- Validate daily coverage, reporting timezones, and unchanged source filters for both weeks before using these comparisons operationally.
- Request Search Console query, page, device, and country breakdowns for both weeks to locate the impression and click increases; compare CTR and position within those segments rather than asserting a ranking-driven cause.
- Request PostHog new-versus-returning user and acquisition-channel breakdowns; verify identity deduplication and session definitions before interpreting user growth.
- Verify that the PostHog conversion event and counting rules were unchanged, then compare session and conversion cohorts by channel to assess whether the nearly unchanged aggregate conversion rate hides differing segment outcomes.
