# Weekly analytics: dev-retry

Both sources have complete weekly coverage. Search Console clicks grew alongside higher impressions, higher CTR and a lower average position. Separately, PostHog conversions and conversion rate increased, while sessions grew more modestly. These aggregate movements support follow-up investigation, not causal attribution or a conclusion that the gains will persist.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 821 | 1067 | 246 | 29.963459 | count | ok |
| impressions | 16423 | 18989 | 2566 | 15.624429 | count | ok |
| position | 7.935 | 7.235 | -0.7 | -8.821676 | position | ok |
| ctr | 0.049991 | 0.05619 | 0.0062 | 12.401385 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1404 | 1474 | 70 | 4.985755 | count | ok |
| users | 1203 | 1244 | 41 | 3.408146 | count | ok |
| conversions | 56 | 63 | 7 | 12.5 | count | ok |
| conversion_rate | 0.039886 | 0.042741 | 0.002855 | 7.157394 | ratio | ok |

## Findings

- PostHog conversions increased from 56 to 63, an absolute gain of 7 and a 12.5% weekly increase. This is a positive outcome-volume signal, but the aggregate does not establish business value or sustained improvement. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.
- Search Console clicks rose from 821 to 1067, a gain of 246 and a 29.963459% weekly increase. This substantial search-click increase warrants checking which queries and landing pages contributed, without treating it as a measured increase in product sessions. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- PostHog conversion rate increased from 0.03988604 to 0.042740841 as fractions of sessions, a 7.157394% relative weekly increase. The higher aggregate rate is encouraging, but it does not establish a statistically reliable improvement or identify a cause. Evidence: posthog.conversion_rate.previous, posthog.conversion_rate.current, posthog.conversion_rate.wow_pct.

## Limitations

- All observations come from the supplied synthetic fixture; they are not live customer data or evidence of actual business performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations. They are neither interchangeable nor additive, and these aggregates cannot attribute PostHog outcomes to search clicks. (source_distinction)
- Weekly totals lack segment, funnel, event-definition and longer-term context. Complete day coverage does not establish causation, statistical significance, persistence or revenue impact. (aggregate_only)
- The first Search Console fetch returned a recoverable synthetic error. Retrying succeeded before calculation; both weeks have complete observed-day coverage and no values were imputed. (recovered_fetch)

## Next checks

- Validate the PostHog conversion event definition and inspect funnel steps and conversions by channel, device and landing page to locate the outcome gain and rule out tracking changes; these breakdowns are not supplied here.
- Inspect Search Console query and page contributions to clicks, impressions and CTR, separating brand and non-brand terms and checking device mix before attributing the increase to ranking or demand changes.
- Compare additional complete weeks and daily PostHog conversion counts and sessions to assess whether the conversion-rate movement persists; evaluate uncertainty before changing acquisition spending or product priorities.
