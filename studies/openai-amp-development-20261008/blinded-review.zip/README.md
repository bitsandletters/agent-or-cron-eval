# Blinded human review

Rate each report against its synthetic fixture. Do not access the controller or mapping key.

Usefulness: 1 unusable, 3 usable with edits, 5 immediately useful. Prioritization: 1 misses major issues, 3 mixed, 5 selects the most relevant evidence. Clarity: 1 confusing, 3 understandable, 5 concise and precise. Flag unsupported causal explanations, recommendations, or numeric prose even if machine scoring passed. Retain missing reports. Two independent reviewers are preferable; reconcile disagreement after ratings. Content may reveal treatment through writing style; this is metadata blinding, not guaranteed anonymity.
