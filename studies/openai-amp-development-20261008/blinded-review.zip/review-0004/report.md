# Weekly analytics: dev-incomplete

No week-over-week performance change can be established. Both sources report only four of seven observed days for the current week, attributed by the fixture to synthetic delayed ingestion. Search Console provides partial clicks and impressions but no current position; PostHog provides no current KPI values. Restore coverage and missing metrics before evaluating acquisition, ranking, or conversion performance.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 975 | 585 | unknown | unknown | count | incomplete |
| impressions | 19508 | 11705 | unknown | unknown | count | incomplete |
| position | 6.378 | unknown | unknown | unknown | position | incomplete |
| ctr | 0.049979 | 0.049979 | unknown | unknown | ratio | incomplete |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1729 | unknown | unknown | unknown | count | incomplete |
| users | 1441 | unknown | unknown | unknown | count | incomplete |
| conversions | 86 | unknown | unknown | unknown | count | incomplete |
| conversion_rate | 0.04974 | unknown | unknown | unknown | ratio | incomplete |

## Findings

- PostHog recorded 86 conversions in the previous week, but the current value is unavailable and coverage is incomplete. Conversion performance cannot be assessed; the missing value is not evidence of an absence of conversions. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.wow_pct.
- Search Console shows 585 clicks in the incomplete current week and 975 in the complete previous week. These totals do not establish an acquisition decline: their observation windows differ, so the week-over-week change is withheld. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.wow_pct.
- Search Console's previous position was 6.378, but current position is unavailable and coverage is incomplete. There is no supported ranking-change finding, and the available position data cannot establish a ranking explanation for the partial traffic counts. Evidence: search_console.position.previous, search_console.position.current, search_console.position.wow_pct.

## Limitations

- This report describes a synthetic fixture, not live customer performance; follow-up checks are recommendations, not actions performed. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations. Do not add, substitute, or equate them, or infer a cross-source funnel from these aggregates. (source_distinction)
- Search Console has seven observed days in the previous week and four in the current week, with synthetic delayed ingestion reported. All absolute and percentage changes are withheld, including CTR; partial totals and ratios are not full-week trends and must not be extrapolated. (incomplete_data)
- Search Console's current position is null. Ranking performance is unknown; retain the null rather than replacing it with zero or inferring position from clicks or impressions. (missing_values)
- PostHog has seven observed days in the previous week and four in the current week, with synthetic delayed ingestion reported. All absolute and percentage changes are withheld; coverage metadata does not imply that current KPI totals are available. (incomplete_data)
- PostHog's current sessions, users, and conversions are null, so its current conversion rate is also unavailable. Neither traffic nor conversion performance can be assessed; missing values do not mean zero activity. (missing_values)
- Weekly aggregates contain no daily, query, page, channel, or funnel breakdowns. They cannot establish causes or show which days or segments are missing. (aggregate_only)

## Next checks

- First inspect the reported ingestion delay for each source and verify day-by-day coverage for the current reporting interval. Backfill missing days where possible, then require seven observed days in both weeks before recalculating comparisons; do not extrapolate the partial week.
- Investigate why PostHog's current metrics are null despite reported partial coverage. Check extraction results, event availability, and the session, user, and conversion definitions; restore actual totals before calculating conversions divided by sessions.
- Check the Search Console extraction for missing current position and restore that metric. After full coverage is confirmed, review clicks, impressions, CTR, and position by query and page to locate any supported changes; do not assume a ranking or CTR cause from aggregate counts.
- After PostHog data is complete, compare its sessions, conversions, and conversion rate within PostHog and use channel or funnel breakdowns to investigate any changes. Keep this analysis separate from Search Console click counts.
