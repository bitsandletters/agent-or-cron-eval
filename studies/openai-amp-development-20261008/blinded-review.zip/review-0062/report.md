# Weekly analytics: dev-retry

Both source-specific weekly views improved: Search Console recorded stronger clicks and average position, while PostHog recorded more conversions and a higher conversion rate. These are different measurement populations and should be interpreted independently; aggregate weekly data does not establish causes.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 821 | 1067 | 246 | 29.963459 | count | ok |
| impressions | 16423 | 18989 | 2566 | 15.624429 | count | ok |
| position | 7.935 | 7.235 | -0.7 | -8.821676 | position | ok |
| ctr | 0.049991 | 0.05619 | 0.0062 | 12.401385 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1404 | 1474 | 70 | 4.985755 | count | ok |
| users | 1203 | 1244 | 41 | 3.408146 | count | ok |
| conversions | 56 | 63 | 7 | 12.5 | count | ok |
| conversion_rate | 0.039886 | 0.042741 | 0.002855 | 7.157394 | ratio | ok |

## Findings

- Search Console clicks increased 29.963459% week over week, the clearest acquisition-side change in this snapshot. Evidence: search_console.clicks.wow_pct.
- PostHog conversion rate rose 7.157394% week over week; this complements the increase in conversion count without implying a cause. Evidence: posthog.conversion_rate.wow_pct.
- Average Search Console position improved by 0.7 positions (the recorded change is -0.7). Evidence: search_console.position.absolute_change.

## Limitations

- This report uses a synthetic development fixture, not live customer or production data; treat it as an example of the provided measurements only. (synthetic_data)
- Search Console clicks and PostHog sessions describe different populations and measurement systems; do not equate, add, or substitute them. (source_distinction)

## Next checks

- Break down Search Console clicks, impressions, CTR, and position by query, page, and device to identify where the aggregate change is concentrated.
- Validate PostHog conversion event definitions and inspect conversion rate by channel, landing page, and device before attributing the increase.
- Compare subsequent complete weeks and check for tracking or reporting changes before treating these week-over-week movements as a durable trend.
