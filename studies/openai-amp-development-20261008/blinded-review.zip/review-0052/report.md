# Weekly analytics: dev-incomplete

No week-over-week change can be established: both sources have only four of seven observed days in the current period, versus complete previous periods. Search Console has partial click and impression totals but no current position; all current PostHog KPI values are unavailable. Restore coverage and missing values before interpreting performance.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 975 | 585 | unknown | unknown | count | incomplete |
| impressions | 19508 | 11705 | unknown | unknown | count | incomplete |
| position | 6.378 | unknown | unknown | unknown | position | incomplete |
| ctr | 0.049979 | 0.049979 | unknown | unknown | ratio | incomplete |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1729 | unknown | unknown | unknown | count | incomplete |
| users | 1441 | unknown | unknown | unknown | count | incomplete |
| conversions | 86 | unknown | unknown | unknown | count | incomplete |
| conversion_rate | 0.04974 | unknown | unknown | unknown | ratio | incomplete |

## Findings

- PostHog conversion performance cannot be assessed: the previous period recorded 86 conversions, but the current count is unavailable and coverage is incomplete. The unavailable count does not establish a loss of conversions; week-over-week change is withheld. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.wow_pct.
- Search Console reports 585 clicks in the incomplete current period and 975 in the complete previous period. These totals do not establish a weekly decline because coverage differs; week-over-week change is withheld. Evidence: search_console.clicks.current, search_console.clicks.previous, search_console.clicks.wow_pct.

## Limitations

- This report uses only the supplied synthetic fixture; it describes no live customer performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations and cannot be substituted, added, or equated. CTR is clicks divided by impressions; conversion rate is conversions divided by sessions. (source_distinction)
- Search Console current coverage is four of seven expected days, with Synthetic delayed ingestion reported; previous coverage is complete. All absolute and percentage changes are withheld, including CTR and position. Partial totals must not be extrapolated to a complete week. (incomplete_data)
- Current Search Console position is null, so ranking performance cannot be assessed. Missing values remain unknown and are not replaced with zero. (missing_values)
- PostHog current coverage is four of seven expected days, with Synthetic delayed ingestion reported; previous coverage is complete. All absolute and percentage changes are withheld. Coverage metadata does not establish availability of metric values. (incomplete_data)
- Current PostHog sessions, users, conversions, and conversion rate are null. Neither traffic nor conversion performance can be assessed, and unavailable values must not be treated as zero activity. (missing_values)

## Next checks

- For each source, inspect daily ingestion coverage for the current reporting period, identify the unobserved dates, and confirm backfill before recalculating weekly comparisons. Keep reporting boundaries consistent across reruns.
- Validate the PostHog extraction for sessions, users, and conversions against the supplied data contract; determine why current aggregates are null despite observed-day metadata. Recover those values and verify conversion rate as conversions divided by sessions.
- Check the Search Console extraction for the missing current position. After full coverage is available, verify click and impression totals and recompute CTR as clicks divided by impressions before evaluating weekly changes.
