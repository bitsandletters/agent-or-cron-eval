# Weekly analytics: dev-incomplete

Both sources cover only four of seven days in the current week, so no week-over-week change is safely comparable. Search Console has partial current clicks and impressions but a missing current position; PostHog current metrics are unavailable. Treat apparent differences in raw weekly totals as incomplete reporting, not demonstrated performance movement.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 975 | 585 | unknown | unknown | count | incomplete |
| impressions | 19508 | 11705 | unknown | unknown | count | incomplete |
| position | 6.378 | unknown | unknown | unknown | position | incomplete |
| ctr | 0.049979 | 0.049979 | unknown | unknown | ratio | incomplete |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1729 | unknown | unknown | unknown | count | incomplete |
| users | 1441 | unknown | unknown | unknown | count | incomplete |
| conversions | 86 | unknown | unknown | unknown | count | incomplete |
| conversion_rate | 0.04974 | unknown | unknown | unknown | ratio | incomplete |

## Findings

- Search Console click movement cannot yet be assessed: delayed ingestion leaves the current week incomplete, so the raw totals are not a comparable week-over-week signal. Evidence: search_console.clicks.wow_pct.
- PostHog activity and conversion movement cannot be assessed because current sessions and other current metrics are missing and the period is incomplete. Evidence: posthog.sessions.wow_pct.

## Limitations

- This report uses a synthetic development fixture and is not evidence of live customer or production performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations and must not be equated, substituted, or added together. (source_distinction)
- At least one week has fewer than seven observed days; changes are withheld. (incomplete_data)
- Source metrics contain null values; do not replace them with zero. (missing_values)
- At least one week has fewer than seven observed days; changes are withheld. (incomplete_data)
- Source metrics contain null values; do not replace them with zero. (missing_values)

## Next checks

- After delayed ingestion completes, verify both sources report all seven days for each week, then recalculate the comparisons.
- Check Search Console ingestion for the missing current-period position value and confirm it is available before interpreting ranking movement.
- Confirm PostHog session, user, and conversion data for the current period; only then assess conversion_rate against the prior complete week.
