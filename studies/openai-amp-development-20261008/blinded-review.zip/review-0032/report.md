# Weekly analytics: dev-zero

Current-week activity is present in both sources, but no KPI supports a week-over-week percentage comparison: prior counts are zero and prior ratios and search position are unavailable. Both sources report seven observed days in each week; complete day coverage does not resolve these baseline limits. Treat the current week as a descriptive baseline, not evidence of sustained growth or improved conversion efficiency.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 0 | 18 | 18 | unknown | count | zero_baseline |
| impressions | 0 | 297 | 297 | unknown | count | zero_baseline |
| position | unknown | 9.19 | unknown | unknown | position | missing |
| ctr | unknown | 0.060606 | unknown | unknown | ratio | missing |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 0 | 40 | 40 | unknown | count | zero_baseline |
| users | 0 | 35 | 35 | unknown | count | zero_baseline |
| conversions | 0 | 2 | 2 | unknown | count | zero_baseline |
| conversion_rate | unknown | 0.05 | unknown | unknown | ratio | missing |

## Findings

- PostHog recorded 2 conversions versus 0 previously, an absolute increase of 2. Percentage growth is undefined from the zero baseline; this does not establish a sustained conversion trend. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.
- Search Console recorded 18 clicks versus 0 previously, an absolute increase of 18. The zero baseline prevents a week-over-week percentage comparison, so the observed activity should not be presented as a percentage growth rate. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- PostHog's current conversion_rate is 0.05 as a fraction; the previous rate is unavailable. Neither an absolute rate change nor a percentage change is defined, so improved conversion efficiency cannot be established. Evidence: posthog.conversion_rate.previous, posthog.conversion_rate.current, posthog.conversion_rate.absolute_change, posthog.conversion_rate.wow_pct.

## Limitations

- This report uses only synthetic fixture data and makes no claims about live customer performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations; they are not added, equated, or used to infer a cross-source funnel. (source_distinction)
- Previous search position is null, preventing a ranking comparison; it is not replaced with zero. Full observed-day coverage does not imply that every metric is available. (missing_values)
- Previous clicks and impressions are zero, making their percentage changes undefined. Previous CTR is also undefined because impressions are zero; both CTR changes remain null. (zero_denominator)
- Previous sessions, users, and conversions are zero, so their percentage changes are undefined. Previous conversion_rate is undefined because sessions are zero; both rate changes remain null. (zero_denominator)
- Weekly aggregates do not establish causes, attribution, statistical reliability, or persistence. The small current conversion count warrants caution. (aggregate_scope)

## Next checks

- Verify separately for each source that the prior zero counts reflect observed inactivity rather than collection or configuration problems; inspect daily coverage and source settings without changing the supplied values.
- Audit PostHog conversion event definitions and deduplication, then inspect sessions and conversions by acquisition channel and landing page to investigate the current activity without assuming Search Console clicks became those sessions.
- Inspect Search Console query and page breakdowns for current impressions and clicks, and investigate why previous position is unavailable; do not infer an SEO cause from these totals.
- Collect another complete week and compare against the current nonzero baseline, reviewing conversion counts alongside conversion_rate before deciding whether performance has improved.
