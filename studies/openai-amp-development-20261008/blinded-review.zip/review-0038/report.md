# Weekly analytics: dev-incomplete

Weekly performance cannot be compared reliably: both sources report only four of seven current-week days, versus complete previous weeks, with synthetic delayed ingestion noted. PostHog current metrics and Search Console current position are unavailable. Treat the available Search Console totals as partial observations, not evidence of a traffic decline; prioritize data recovery before performance decisions.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 975 | 585 | unknown | unknown | count | incomplete |
| impressions | 19508 | 11705 | unknown | unknown | count | incomplete |
| position | 6.378 | unknown | unknown | unknown | position | incomplete |
| ctr | 0.049979 | 0.049979 | unknown | unknown | ratio | incomplete |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1729 | unknown | unknown | unknown | count | incomplete |
| users | 1441 | unknown | unknown | unknown | count | incomplete |
| conversions | 86 | unknown | unknown | unknown | count | incomplete |
| conversion_rate | 0.04974 | unknown | unknown | unknown | ratio | incomplete |

## Findings

- PostHog current conversions are unavailable, against 86 in the previous week. Conversion outcomes cannot be assessed for the current week; the withheld comparison is not evidence of a conversion decline. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.wow_pct.
- Search Console records 585 current clicks versus 975 previously, but current coverage is incomplete. A weekly click trend cannot be established from these unequal-coverage totals; percentage change is withheld. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.wow_pct.

## Limitations

- All observations come from the supplied synthetic fixture; they do not describe live customer performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations and must not be combined, equated, or substituted for one another. (source_distinction)
- Search Console has seven previous-week observed days but only four current-week days, attributed in the fixture to synthetic delayed ingestion. All weekly changes are withheld, including CTR; partial totals must not be extrapolated. (incomplete_data)
- Current Search Console position is null, so ranking performance cannot be assessed. Preserve this unknown rather than replacing it with zero. (missing_values)
- PostHog has seven previous-week observed days but only four current-week days, attributed in the fixture to synthetic delayed ingestion. All absolute and percentage changes are withheld. (incomplete_data)
- All current PostHog metrics are null, including the derived conversion rate. Observed-day metadata does not make these values available; no traffic or conversion conclusion is supported, and nulls must not become zeros. (missing_values)

## Next checks

- Check ingestion completion for each source independently, identify the missing current-week dates, and rerun the report after both periods have complete coverage; do not estimate missing days.
- Investigate why PostHog current sessions, users, and conversions remain null despite observed-day metadata. Verify export completeness and session and conversion event availability before recomputing conversion rate from conversions divided by sessions.
- Verify availability of Search Console current position. Once coverage is complete, examine clicks, impressions, CTR, and position by query and landing page before proposing explanations for any confirmed change.
