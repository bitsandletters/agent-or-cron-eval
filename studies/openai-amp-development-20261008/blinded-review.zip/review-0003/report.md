# Weekly analytics: dev-zero

Both sources report activity in the current week after zero activity in the prior week, but those zero baselines prevent meaningful week-over-week percentage comparisons. Search Console position is missing for the prior week, and the conversion rate is undefined there because there were no sessions. Treat the current-week ratios as descriptive only; investigate the prior-week baselines and underlying source data before drawing trend or causal conclusions.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 0 | 18 | 18 | unknown | count | zero_baseline |
| impressions | 0 | 297 | 297 | unknown | count | zero_baseline |
| position | unknown | 9.19 | unknown | unknown | position | missing |
| ctr | unknown | 0.060606 | unknown | unknown | ratio | missing |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 0 | 40 | 40 | unknown | count | zero_baseline |
| users | 0 | 35 | 35 | unknown | count | zero_baseline |
| conversions | 0 | 2 | 2 | unknown | count | zero_baseline |
| conversion_rate | unknown | 0.05 | unknown | unknown | ratio | missing |

## Findings

- Search Console clicks rose from a zero prior-week baseline, so a percentage change cannot be calculated; the increase alone does not establish a trend. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.wow_pct.
- PostHog sessions also start from a zero prior-week baseline, preventing a week-over-week percentage comparison; do not equate these sessions with Search Console clicks. Evidence: posthog.sessions.previous, posthog.sessions.current, posthog.sessions.wow_pct.
- Search Console CTR has no comparable prior-week value because the prior week had no impressions; a week-over-week CTR change is unavailable. Evidence: search_console.ctr.previous, search_console.ctr.current, search_console.ctr.wow_pct.

## Limitations

- This report uses a synthetic fixture, not live customer analytics; results are illustrative and should not be treated as operational performance. (synthetic_data)
- Search Console clicks and PostHog sessions describe different populations and are not interchangeable or additive. (source_distinction)
- Source metrics contain null values; do not replace them with zero. (missing_values)
- A zero denominator or baseline makes at least one ratio or percentage change undefined. (zero_denominator)
- A zero denominator or baseline makes at least one ratio or percentage change undefined. (zero_denominator)

## Next checks

- Check whether the prior-week zero values reflect a genuine launch or a collection, configuration, or ingestion gap in each source.
- Review Search Console query and page-level impressions, clicks, CTR, and position over additional complete weeks before assessing search performance.
- Inspect PostHog session and conversion event definitions and validate the funnel across additional complete weeks; do not infer a cause from these aggregate counts.
