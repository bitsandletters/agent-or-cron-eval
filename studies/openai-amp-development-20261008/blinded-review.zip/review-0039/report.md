# Weekly analytics: dev-growth

Both sources have full observed coverage for both weeks, and all KPI comparisons are available. Search Console impressions and clicks increased, while CTR was nearly unchanged and average position decreased. Separately, PostHog sessions, users and conversions increased, while conversion rate changed little. These aggregate movements do not establish causes or connect the two source populations.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 986 | 1232 | 246 | 24.94929 | count | ok |
| impressions | 19716 | 24646 | 4930 | 25.005072 | count | ok |
| position | 6.6 | 6.3 | -0.3 | -4.545455 | position | ok |
| ctr | 0.05001 | 0.049988 | -0.000022 | -0.044623 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1775 | 2130 | 355 | 20 | count | ok |
| users | 1479 | 1785 | 306 | 20.689655 | count | ok |
| conversions | 89 | 107 | 18 | 20.224719 | count | ok |
| conversion_rate | 0.050141 | 0.050235 | 0.000094 | 0.187266 | ratio | ok |

## Findings

- Search Console impressions increased from 19716 to 24646, a gain of 4930 (25.005072% week over week), the largest relative KPI increase in the report. Evidence: search_console.impressions.previous, search_console.impressions.current, search_console.impressions.absolute_change, search_console.impressions.wow_pct.
- Search Console clicks increased from 986 to 1232, a gain of 246 (24.94929% week over week). This is an observed increase in search clicks, not a count of PostHog sessions. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- PostHog conversions increased from 89 to 107, a gain of 18 (20.224719% week over week). The conversion-count gain merits follow-up, but alone does not establish improved conversion efficiency or its cause. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.

## Limitations

- All data are supplied synthetic fixtures; these results do not describe live customer performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations. They must not be substituted, added, equated, or interpreted as a shared funnel. (source_distinction)
- Full observed day coverage permits weekly comparisons but does not validate tracking accuracy. Weekly aggregates provide no segment breakdown, causal attribution, or evidence of statistical significance. (aggregate_only)

## Next checks

- Request daily Search Console query and landing-page breakdowns for the same periods to locate impression and click gains and assess whether CTR or position changes vary by segment.
- Validate PostHog conversion-event definitions, duplicate handling and session instrumentation across both periods before interpreting the conversion-count increase.
- Request PostHog sessions, conversions and conversion rates by acquisition channel and landing page for the same periods to distinguish volume growth from within-segment efficiency changes, without equating sessions to Search Console clicks.
