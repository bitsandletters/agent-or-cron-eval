# Weekly analytics: dev-growth

Both sources have complete coverage for both weeks. Search Console clicks increased 24.94929% alongside a similar increase in impressions, with CTR nearly unchanged. Separately, PostHog sessions increased 20% and conversions increased 20.224719%, while conversion rate was nearly unchanged. The aggregates show higher volume, not a material improvement in conversion efficiency; they do not establish causes or connect search clicks to PostHog sessions.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 986 | 1232 | 246 | 24.94929 | count | ok |
| impressions | 19716 | 24646 | 4930 | 25.005072 | count | ok |
| position | 6.6 | 6.3 | -0.3 | -4.545455 | position | ok |
| ctr | 0.05001 | 0.049988 | -0.000022 | -0.044623 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1775 | 2130 | 355 | 20 | count | ok |
| users | 1479 | 1785 | 306 | 20.689655 | count | ok |
| conversions | 89 | 107 | 18 | 20.224719 | count | ok |
| conversion_rate | 0.050141 | 0.050235 | 0.000094 | 0.187266 | ratio | ok |

## Findings

- PostHog conversions rose from 89 to 107, an absolute increase of 18 and a week-over-week increase of 20.224719%. This is the principal recorded outcome gain; these aggregate counts do not identify its cause. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.
- Search Console clicks rose from 986 to 1232, an absolute increase of 246 and a week-over-week increase of 24.94929%. This shows more search clicks, not a measured increase in PostHog sessions or conversions. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- PostHog conversion_rate increased from 0.050140845 to 0.050234742 as fractions, with a reported absolute change of 0.000094 and a relative week-over-week increase of 0.187266%. Conversion efficiency was nearly unchanged; this small aggregate difference does not establish a meaningful or statistically significant improvement. Evidence: posthog.conversion_rate.previous, posthog.conversion_rate.current, posthog.conversion_rate.absolute_change, posthog.conversion_rate.wow_pct.

## Limitations

- These are synthetic fixture data, not live customer results; use this report to evaluate analysis rather than make production decisions. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations. They must not be added, substituted, or equated; these aggregates cannot attribute PostHog conversions to search clicks. (source_distinction)
- Weekly totals lack daily, query, page, channel, device, and cohort breakdowns. They cannot establish causes, persistence, or the statistical significance of rate changes. Complete coverage does not by itself verify tracking accuracy. (aggregate_only)

## Next checks

- In PostHog, confirm that conversion definitions and event collection were unchanged, then break sessions and conversions down by channel, landing page, and device to locate the recorded outcome gain and compare conversion rates within those segments.
- In Search Console, compare daily, query, page, and device breakdowns of clicks, impressions, CTR, and position to determine where increased search exposure and clicks were concentrated; investigate causes only after obtaining that evidence.
- Review subsequent complete weeks to assess whether the gains persist. Use an appropriate uncertainty analysis before treating the small conversion-rate change as meaningful, and verify attribution definitions before attempting any cross-source funnel analysis.
