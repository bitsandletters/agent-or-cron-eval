# Weekly analytics: dev-quiet

Both sources have complete seven-day coverage in each week. Search Console clicks and average position improved; PostHog conversions increased, while its conversion rate was nearly unchanged. These are separate source populations and should not be combined.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 896 | 932 | 36 | 4.017857 | count | ok |
| impressions | 17923 | 18420 | 497 | 2.772973 | count | ok |
| position | 6.833 | 6.633 | -0.2 | -2.926972 | position | ok |
| ctr | 0.049992 | 0.050597 | 0.000606 | 1.211295 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1679 | 1729 | 50 | 2.977963 | count | ok |
| users | 1417 | 1448 | 31 | 2.187721 | count | ok |
| conversions | 67 | 69 | 2 | 2.985075 | count | ok |
| conversion_rate | 0.039905 | 0.039907 | 0.000003 | 0.006906 | ratio | ok |

## Findings

- Search Console clicks rose week over week by 4.017857% (36 clicks). This is the largest relative gain among the reported acquisition-volume measures; the aggregate data do not establish a cause. Evidence: search_console.clicks.wow_pct, search_console.clicks.absolute_change.
- Average Search Console position improved from 6.833 to 6.633 (absolute change -0.2; -2.926972% week over week, where a lower position is better). Evidence: search_console.position.previous, search_console.position.current, search_console.position.absolute_change, search_console.position.wow_pct.
- PostHog recorded 2 more conversions, a 2.985075% week-over-week increase; this aggregate change alone does not explain what drove it. Evidence: posthog.conversions.absolute_change, posthog.conversions.wow_pct.

## Limitations

- This report uses a synthetic fixture, not live customer data; treat it as an evaluation example rather than operational performance evidence. (synthetic_data)
- Search Console clicks and PostHog sessions represent different populations and measurement systems; do not substitute, add, or equate them. (source_distinction)

## Next checks

- Validate the underlying Search Console and PostHog extracts and metric definitions against the intended reporting windows before using this pattern for live reporting.
- Review Search Console query and landing-page segments to localize the click and position changes; the aggregate weekly totals do not identify their drivers.
- Inspect PostHog conversion events and relevant funnel segments to confirm event instrumentation and investigate the conversion-count change without assuming a cause.
