# Weekly analytics: dev-decline

Both sources have complete weekly coverage and show declines in traffic volume. Prioritize the loss of Search Console clicks and PostHog conversions. Search CTR also fell and average position worsened, while PostHog conversion rate was nearly unchanged despite fewer sessions. These separate populations do not establish a shared cause or an attribution link.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 1535 | 1074 | -461 | -30.032573 | count | ok |
| impressions | 30691 | 28645 | -2046 | -6.666449 | count | ok |
| position | 5.753 | 7.053 | 1.3 | 22.596906 | position | ok |
| ctr | 0.050015 | 0.037493 | -0.012521 | -25.035075 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 2445 | 1956 | -489 | -20 | count | ok |
| users | 2140 | 1742 | -398 | -18.598131 | count | ok |
| conversions | 122 | 98 | -24 | -19.672131 | count | ok |
| conversion_rate | 0.049898 | 0.050102 | 0.000204 | 0.409834 | ratio | ok |

## Findings

- Search Console clicks fell from 1535 to 1074 (absolute change: -461 clicks; week-over-week change: -30.032573%). Investigate the search traffic loss as the leading acquisition concern. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- PostHog conversions fell from 122 to 98 (absolute change: -24 conversions; week-over-week change: -19.672131%). This is the main observed outcome decline; the aggregate alone does not identify its cause. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.
- Search Console CTR fell from 0.050014662 to 0.037493454 (fractions; week-over-week change: -25.035075%). The weaker click yield warrants query- and page-level investigation rather than attributing the click decline solely to reduced impressions. Evidence: search_console.ctr.previous, search_console.ctr.current, search_console.ctr.absolute_change, search_console.ctr.wow_pct.

## Limitations

- All observations are synthetic fixture data, not live customer performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations and must not be added, equated, or treated as a linked acquisition funnel. (source_distinction)
- Complete weekly coverage permits arithmetic comparisons, but aggregate totals do not establish causes, statistical significance, segment behavior, or whether instrumentation changed. Average search position can also reflect query mix. (aggregate_only)

## Next checks

- Break Search Console clicks, impressions, CTR, and position down by query, page, device, and country for the same periods; prioritize segments contributing the largest click losses and check whether CTR and position moved within those segments.
- Break PostHog sessions and conversions down by channel, landing page, and device, then inspect funnel steps within affected segments. Check tracking and conversion definitions before attributing the outcome decline to user behavior.
- Review daily patterns and additional complete weeks for each source independently to distinguish a persistent decline from ordinary weekly variation; do not infer a cross-source attribution link from these totals.
