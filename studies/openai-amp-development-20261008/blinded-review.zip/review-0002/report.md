# Weekly analytics: dev-decline

Both sources have complete observed-day coverage for both reporting weeks. Search Console clicks and CTR declined, impressions fell, and average position worsened. Separately, PostHog sessions, users, and conversions declined while conversion_rate increased slightly. These aggregate changes describe different populations and do not establish causes.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 1535 | 1074 | -461 | -30.032573 | count | ok |
| impressions | 30691 | 28645 | -2046 | -6.666449 | count | ok |
| position | 5.753 | 7.053 | 1.3 | 22.596906 | position | ok |
| ctr | 0.050015 | 0.037493 | -0.012521 | -25.035075 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 2445 | 1956 | -489 | -20 | count | ok |
| users | 2140 | 1742 | -398 | -18.598131 | count | ok |
| conversions | 122 | 98 | -24 | -19.672131 | count | ok |
| conversion_rate | 0.049898 | 0.050102 | 0.000204 | 0.409834 | ratio | ok |

## Findings

- Search Console clicks fell from 1535 to 1074, an absolute change of -461 and a week-over-week change of -30.032573%. This is the largest relative decline among the reported KPIs and the first priority for search-specific validation; the weekly totals do not identify its cause. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- Search Console CTR fell from 0.050014662 to 0.037493454 as a fraction of impressions, an absolute ratio change of -0.012521 and a relative week-over-week change of -25.035075%. The lower share of impressions receiving clicks warrants query- and page-level review; it does not establish why click propensity changed. Evidence: search_console.ctr.previous, search_console.ctr.current, search_console.ctr.absolute_change, search_console.ctr.wow_pct.
- PostHog sessions fell from 2445 to 1956, an absolute change of -489 and a week-over-week change of -20.0%. This is the largest relative decline within PostHog and warrants channel-level and tracking validation independently of Search Console clicks. Evidence: posthog.sessions.previous, posthog.sessions.current, posthog.sessions.absolute_change, posthog.sessions.wow_pct.

## Limitations

- All values come from the supplied synthetic fixture, not live customer data. Findings describe this fixture and cannot establish actual business performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations. They are reported separately and must not be substituted, added, or equated; concurrent declines do not demonstrate a shared cause. (source_distinction)
- The packet provides weekly aggregate KPIs, not daily patterns, query/page/channel segments, tracking audits, or uncertainty estimates. Complete observed-day coverage supports these comparisons but does not prove measurement accuracy, explain causes, or establish statistical significance. The calculation tool emitted no warnings. (aggregate_only)

## Next checks

- For a subsequent Search Console investigation, obtain daily query and page breakdowns with matching dates and filters; locate where click and CTR declines concentrate, then compare impressions and average position within those same segments.
- For a subsequent PostHog investigation, review daily sessions by channel and landing page; verify session definitions, timezone boundaries, event ingestion, and tracking changes before attributing the decline to visitor behavior.
- Validate the PostHog conversion event definition and compare conversion counts and conversions divided by sessions within consistent channel cohorts; determine whether the nearly unchanged aggregate conversion rate masks segment differences.
