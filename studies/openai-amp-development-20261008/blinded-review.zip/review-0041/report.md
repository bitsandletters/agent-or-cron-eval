# Weekly analytics: dev-zero

Both sources have seven observed days in each week. Search Console recorded 18 clicks and 297 impressions, while PostHog separately recorded 40 sessions, 35 users and 2 conversions; their previous count values were zero. Absolute count increases are available, but no KPI supports a week-over-week percentage comparison. Current CTR is 0.060606061 and conversion_rate is 0.05, both expressed as fractions; previous rates are undefined. These synthetic observations do not establish causes or a sustained growth trend.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 0 | 18 | 18 | unknown | count | zero_baseline |
| impressions | 0 | 297 | 297 | unknown | count | zero_baseline |
| position | unknown | 9.19 | unknown | unknown | position | missing |
| ctr | unknown | 0.060606 | unknown | unknown | ratio | missing |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 0 | 40 | 40 | unknown | count | zero_baseline |
| users | 0 | 35 | 35 | unknown | count | zero_baseline |
| conversions | 0 | 2 | 2 | unknown | count | zero_baseline |
| conversion_rate | unknown | 0.05 | unknown | unknown | ratio | missing |

## Findings

- PostHog conversions rose from 0 to 2, an absolute increase of 2. This observed outcome merits validation, but the zero baseline leaves percentage growth undefined; it does not establish sustained improvement. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.
- Search Console impressions increased from 0 to 297, an absolute increase of 297. Search exposure is observed in the current week, but percentage growth cannot be calculated from the zero baseline. Evidence: search_console.impressions.previous, search_console.impressions.current, search_console.impressions.absolute_change, search_console.impressions.wow_pct.
- PostHog sessions increased from 0 to 40, an absolute increase of 40. Current site activity is observed, but the zero baseline prevents a percentage comparison; these sessions cannot be attributed to Search Console activity from the supplied aggregates. Evidence: posthog.sessions.previous, posthog.sessions.current, posthog.sessions.absolute_change, posthog.sessions.wow_pct.

## Limitations

- The packet contains synthetic data only; these observations do not describe live customers or production performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations. Keep their KPI blocks separate; do not add, substitute, equate or infer attribution between them. (source_distinction)
- Previous Search Console position is null, so neither its absolute nor percentage change is available. Preserve the missing value rather than replacing it with zero. (missing_values)
- Previous clicks and impressions are zero, making their percentage changes undefined. Previous CTR is undefined because impressions are zero, so CTR changes are also unavailable. Complete daily coverage does not resolve these undefined comparisons. (zero_denominator)
- Previous sessions, users and conversions are zero, making their percentage changes undefined. Previous conversion_rate is undefined because sessions are zero, so rate changes are unavailable. Absolute count changes remain available. (zero_denominator)

## Next checks

- Validate the current PostHog conversion events against the intended conversion definition, including duplicate-event handling and session association, before interpreting the observed outcomes.
- Inspect daily records and source configuration separately for each source to confirm that previous zero counts represent observed inactivity rather than collection, filtering or export problems; verify the missing previous Search Console position without filling it with zero.
- Review Search Console query and page breakdowns and PostHog session channel breakdowns separately to locate the observed activity. Any cross-source attribution needs compatible scopes and attribution evidence absent from this packet.
- Compare another fully observed week with a nonzero baseline before calculating percentage growth or assessing persistence of the count increases and current rates.
