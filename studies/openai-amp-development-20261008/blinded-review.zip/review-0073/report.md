# Weekly analytics: dev-incomplete

No week-over-week performance change is supported: both sources have only 4 of 7 observed current-week days, versus complete previous weeks, with synthetic delayed ingestion reported. Search Console has partial click and impression totals but no current position; all current PostHog KPIs are unavailable. Restore coverage and missing values before drawing traffic or conversion conclusions.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 975 | 585 | unknown | unknown | count | incomplete |
| impressions | 19508 | 11705 | unknown | unknown | count | incomplete |
| position | 6.378 | unknown | unknown | unknown | position | incomplete |
| ctr | 0.049979 | 0.049979 | unknown | unknown | ratio | incomplete |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1729 | unknown | unknown | unknown | count | incomplete |
| users | 1441 | unknown | unknown | unknown | count | incomplete |
| conversions | 86 | unknown | unknown | unknown | count | incomplete |
| conversion_rate | 0.04974 | unknown | unknown | unknown | ratio | incomplete |

## Findings

- PostHog conversions are unavailable for the current week, against 86 previously. Incomplete coverage and a missing current value prevent an assessment of conversion performance; the missing count must not be treated as zero. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.wow_pct.
- Search Console records 585 current-week clicks and 975 previous-week clicks, but the current total covers an incomplete week. These totals do not establish a weekly decline; the percentage comparison is withheld. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.wow_pct.
- PostHog sessions are unavailable for the current week, against 1729 previously. The missing total and incomplete coverage leave session growth or decline undetermined; Search Console clicks cannot substitute for sessions. Evidence: posthog.sessions.previous, posthog.sessions.current, posthog.sessions.wow_pct.

## Limitations

- This report uses only the supplied synthetic fixture, not live customer data; it cannot establish real business performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations. They are reported separately and are not added, equated, or substituted; CTR and conversion rate have different denominators. (source_distinction)
- Search Console has 4 of 7 observed current-week days versus 7 of 7 previously, with synthetic delayed ingestion reported. All absolute and percentage changes are withheld, including CTR; partial totals must not be extrapolated. (incomplete_data)
- Current Search Console position is null, so ranking movement cannot be assessed. Preserve the missing value rather than replacing it with zero. (missing_values)
- PostHog has 4 of 7 observed current-week days versus 7 of 7 previously, with synthetic delayed ingestion reported. All absolute and percentage changes are withheld; reported coverage does not make the missing metrics available. (incomplete_data)
- Current PostHog sessions, users, conversions, and conversion rate are null. Traffic and conversion comparisons cannot be made, and unknown values must not be replaced with zero. (missing_values)

## Next checks

- Validate each source's daily ingestion coverage for September 21–27 and rerun the report only after all seven days are observed; retain the same previous reporting period.
- Check the PostHog extraction for missing sessions, users, and conversions despite reported partial coverage. Recover those values before recalculating conversion rate as conversions divided by sessions.
- Check why the Search Console position field is absent and restore it if available. After complete coverage, recompute CTR as clicks divided by impressions and reassess weekly comparisons separately from PostHog.
