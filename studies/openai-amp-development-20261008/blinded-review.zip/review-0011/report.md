# Weekly analytics: dev-growth

Both sources have complete weekly coverage and show higher activity. Search Console clicks rose alongside impressions, with nearly unchanged CTR. Separately, PostHog conversions and sessions increased at similar rates, while conversion rate changed only slightly. This supports a volume-growth interpretation, not a claim of materially improved conversion efficiency or a causal link between the sources.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 986 | 1232 | 246 | 24.94929 | count | ok |
| impressions | 19716 | 24646 | 4930 | 25.005072 | count | ok |
| position | 6.6 | 6.3 | -0.3 | -4.545455 | position | ok |
| ctr | 0.05001 | 0.049988 | -0.000022 | -0.044623 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1775 | 2130 | 355 | 20 | count | ok |
| users | 1479 | 1785 | 306 | 20.689655 | count | ok |
| conversions | 89 | 107 | 18 | 20.224719 | count | ok |
| conversion_rate | 0.050141 | 0.050235 | 0.000094 | 0.187266 | ratio | ok |

## Findings

- PostHog conversions increased from 89 to 107, a gain of 18 (+20.224719% week over week). This is a larger recorded conversion volume, but does not establish revenue growth or explain why conversions increased. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.
- Search Console clicks increased from 986 to 1232, a gain of 246 (+24.94929% week over week). The increase warrants checking which queries and pages contributed, without treating search clicks as site sessions. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- PostHog conversion rate moved only slightly, from 0.050140845 to 0.050234742 as fractions (+0.187266% relative week over week). This small descriptive movement does not establish a meaningful improvement in conversion efficiency. Evidence: posthog.conversion_rate.previous, posthog.conversion_rate.current, posthog.conversion_rate.wow_pct.

## Limitations

- All observations come from the supplied synthetic fixture, not live customer data; they do not support decisions about actual production performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations. Do not add, substitute, equate, or use them to attribute conversion growth to search. (source_distinction)
- Both sources report seven observed days in each week, with no calculation warnings. Weekly aggregates still lack daily patterns, segments, attribution and historical variability; they establish neither causes nor statistical significance. (aggregate_scope)

## Next checks

- In a subsequent analysis, verify that PostHog conversion definitions and instrumentation stayed consistent, then break down sessions, conversions and conversion rate by channel, landing page and device to identify where volume changed.
- Inspect Search Console query and page breakdowns for clicks, impressions, CTR and position to locate the contributors to search growth; keep that analysis separate from PostHog attribution.
- Compare daily trends and additional complete weeks before treating the small conversion-rate movement as a sustained improvement; use session-level outcomes and an appropriate uncertainty analysis if testing a rate change.
