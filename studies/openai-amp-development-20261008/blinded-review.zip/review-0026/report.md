# Weekly analytics: dev-zero

Both sources recorded activity in the current week after zero prior-week baselines, but percentage growth is undefined. Search Console and PostHog measure different populations and should be read separately.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 0 | 18 | 18 | unknown | count | zero_baseline |
| impressions | 0 | 297 | 297 | unknown | count | zero_baseline |
| position | unknown | 9.19 | unknown | unknown | position | missing |
| ctr | unknown | 0.060606 | unknown | unknown | ratio | missing |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 0 | 40 | 40 | unknown | count | zero_baseline |
| users | 0 | 35 | 35 | unknown | count | zero_baseline |
| conversions | 0 | 2 | 2 | unknown | count | zero_baseline |
| conversion_rate | unknown | 0.05 | unknown | unknown | ratio | missing |

## Findings

- Search Console clicks were recorded this week, but the zero prior-week baseline makes a percentage comparison undefined. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- PostHog sessions were recorded this week, but the zero prior-week baseline makes a percentage comparison undefined. Evidence: posthog.sessions.previous, posthog.sessions.current, posthog.sessions.absolute_change, posthog.sessions.wow_pct.
- PostHog recorded conversions, but the zero prior-week baseline makes a percentage comparison undefined. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.

## Limitations

- This report uses a synthetic fixture, not live customer data; do not treat it as production performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations and are not substitutes or additive. (source_distinction)
- Source metrics contain null values; do not replace them with zero. Position and the prior-period CTR are unavailable, preventing their comparison. (missing_values)
- A zero denominator or baseline makes at least one ratio or percentage change undefined; CTR and percentage changes remain unavailable where calculated as null. (zero_denominator)
- A zero denominator or baseline makes at least one ratio or percentage change undefined; conversion rate and percentage changes remain unavailable where calculated as null. (zero_denominator)

## Next checks

- Confirm both source exports cover the stated seven-day periods and that zero prior-week counts reflect actual activity rather than an ingestion or filtering gap.
- Review Search Console query/page-level data to validate the current-week clicks and impressions and investigate the unavailable position and prior CTR values.
- Check PostHog event definitions, session filters, and conversion instrumentation; collect a comparable nonzero baseline before assessing percentage growth or conversion-rate change.
