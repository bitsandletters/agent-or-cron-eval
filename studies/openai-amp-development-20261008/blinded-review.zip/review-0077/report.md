# Weekly analytics: dev-retry

Both sources have seven observed days in each reporting week, and every KPI has a comparable baseline. Search Console clicks and impressions show the largest relative increases; PostHog conversions also increased. Search Console CTR and PostHog conversion rate rose, while average search position decreased. These source-specific observations do not establish a shared population or explain the changes.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 821 | 1067 | 246 | 29.963459 | count | ok |
| impressions | 16423 | 18989 | 2566 | 15.624429 | count | ok |
| position | 7.935 | 7.235 | -0.7 | -8.821676 | position | ok |
| ctr | 0.049991 | 0.05619 | 0.0062 | 12.401385 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1404 | 1474 | 70 | 4.985755 | count | ok |
| users | 1203 | 1244 | 41 | 3.408146 | count | ok |
| conversions | 56 | 63 | 7 | 12.5 | count | ok |
| conversion_rate | 0.039886 | 0.042741 | 0.002855 | 7.157394 | ratio | ok |

## Findings

- Search Console clicks increased from 821 to 1067, a gain of 246 and a 29.963459% week-over-week increase, the largest relative change among the reported KPIs. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- Search Console impressions increased from 16423 to 18989, a gain of 2566 and a 15.624429% week-over-week increase. This shows increased search exposure, but the aggregate totals do not identify which queries or pages account for it. Evidence: search_console.impressions.previous, search_console.impressions.current, search_console.impressions.absolute_change, search_console.impressions.wow_pct.
- PostHog conversions increased from 56 to 63, a gain of 7 and a 12.5% week-over-week increase. The modest absolute gain warrants checking event definitions and the underlying conversion records before treating it as a persistent trend. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.

## Limitations

- All observations come from the supplied synthetic fixture and describe no live customer performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations; they cannot be substituted, added, or equated, and their movements do not establish an acquisition-to-conversion relationship. (source_distinction)
- Complete weekly coverage permits these comparisons, but aggregate counts alone do not establish causes, statistical significance, or a sustained trend. No calculation warnings were emitted. (aggregate_only)

## Next checks

- If detailed Search Console data becomes available, reconcile daily totals to these weeks and compare query and landing-page breakdowns for clicks and impressions to locate the gains; examine CTR and position within the same segments.
- Validate PostHog conversion event definitions, deduplication, filters, and session boundaries across both weeks; reconcile the conversion totals to underlying event records before examining funnel or cohort breakdowns.
- Compare additional complete weeks to assess persistence. Confirm reporting date boundaries and source-specific filters before any further comparison, and keep Search Console and PostHog populations separate.
