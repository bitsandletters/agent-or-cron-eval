# Weekly analytics: dev-growth

Both sources show broader weekly activity, with Search Console clicks and PostHog sessions rising alongside impressions and conversions. PostHog conversion rate was nearly unchanged, while Search Console CTR edged down slightly; these are separate source populations and do not establish a shared funnel or explain the underlying drivers.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 986 | 1232 | 246 | 24.94929 | count | ok |
| impressions | 19716 | 24646 | 4930 | 25.005072 | count | ok |
| position | 6.6 | 6.3 | -0.3 | -4.545455 | position | ok |
| ctr | 0.05001 | 0.049988 | -0.000022 | -0.044623 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1775 | 2130 | 355 | 20 | count | ok |
| users | 1479 | 1785 | 306 | 20.689655 | count | ok |
| conversions | 89 | 107 | 18 | 20.224719 | count | ok |
| conversion_rate | 0.050141 | 0.050235 | 0.000094 | 0.187266 | ratio | ok |

## Findings

- Search Console clicks increased 24.94929% week over week, indicating more search-result visits in this source; investigate which queries and landing pages contributed before attributing a cause. Evidence: search_console.clicks.wow_pct.
- PostHog-recorded conversions increased 20.224719% week over week; inspect conversion events and segment breakdowns to understand where the increase occurred, without assuming Search Console clicks map to these sessions. Evidence: posthog.conversions.wow_pct.
- Search Console CTR's week-over-week change was -0.044623%, a slight dip despite higher clicks and impressions; check query- and page-level CTR before treating this small aggregate movement as a meaningful trend. Evidence: search_console.ctr.wow_pct.

## Limitations

- This report uses a synthetic development fixture, not live customer data; validate patterns against production-quality data before operational decisions. (synthetic_data)
- Search Console clicks and PostHog sessions represent different populations and measurement systems; do not equate, add, or infer a direct relationship between them. (source_distinction)

## Next checks

- Break down Search Console clicks, impressions, CTR, and position by query and landing page to locate the source of the aggregate gains and slight CTR movement.
- Review PostHog conversion definitions, event health, and conversion-rate trends by channel and user segment; compare attribution only with an explicitly aligned measurement method.
- Check subsequent complete seven-day periods to determine whether the observed changes persist; avoid causal conclusions from these aggregate weekly counts alone.
