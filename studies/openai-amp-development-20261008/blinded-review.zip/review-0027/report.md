# Weekly analytics: dev-zero

Both sources have seven observed days in each week, but no KPI supports a week-over-week percentage comparison. Search Console recorded 297 impressions and 18 clicks; separately, PostHog recorded 40 sessions, 35 users and 2 conversions. All count baselines were zero. Current activity is observable, but relative growth and changes in rates or search position cannot be established.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 0 | 18 | 18 | unknown | count | zero_baseline |
| impressions | 0 | 297 | 297 | unknown | count | zero_baseline |
| position | unknown | 9.19 | unknown | unknown | position | missing |
| ctr | unknown | 0.060606 | unknown | unknown | ratio | missing |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 0 | 40 | 40 | unknown | count | zero_baseline |
| users | 0 | 35 | 35 | unknown | count | zero_baseline |
| conversions | 0 | 2 | 2 | unknown | count | zero_baseline |
| conversion_rate | unknown | 0.05 | unknown | unknown | ratio | missing |

## Findings

- Search Console impressions rose from 0 to 297, an absolute increase of 297. This is the largest observed count increase within Search Console, but the zero baseline makes percentage growth undefined; it is not evidence of a measurable relative growth rate. Evidence: search_console.impressions.previous, search_console.impressions.current, search_console.impressions.absolute_change, search_console.impressions.wow_pct.
- PostHog sessions rose from 0 to 40, an absolute increase of 40, the largest observed count increase within PostHog. Percentage growth is undefined because the previous baseline was zero; these sessions must not be equated with search clicks. Evidence: posthog.sessions.previous, posthog.sessions.current, posthog.sessions.absolute_change, posthog.sessions.wow_pct.
- PostHog conversions rose from 0 to 2, an absolute increase of 2. This records current conversion activity, but the zero baseline prevents a percentage growth comparison and does not establish improved conversion efficiency. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.

## Limitations

- This report uses only synthetic fixture data, not live customer activity. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations; they are not interchangeable and must not be added or treated as an attributed funnel. (source_distinction)
- Previous search position is null, so its change cannot be evaluated despite complete day coverage. Missing values remain null, not zero. (missing_values)
- Previous clicks and impressions are zero, so their percentage changes are undefined. Previous CTR is also undefined because impressions were zero; CTR changes remain null. (zero_denominator)
- Previous sessions, users and conversions are zero, so their percentage changes are undefined. Previous conversion rate is undefined because sessions were zero; conversion-rate changes remain null. (zero_denominator)

## Next checks

- Validate the prior-week zero counts against daily source records and confirm unchanged property, project, date and filter settings; full day coverage alone does not validate instrumentation.
- Inspect Search Console query and page breakdowns for the current impressions and clicks, and verify whether prior-week position is unavailable because no impressions were recorded; do not impute it.
- Validate PostHog session and conversion event definitions and deduplication against event-level records before interpreting conversion performance.
- Compare another complete week with nonzero denominators before assessing relative growth or rate changes, keeping the two sources separate.
