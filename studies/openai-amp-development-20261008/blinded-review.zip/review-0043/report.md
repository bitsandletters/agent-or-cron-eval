# Weekly analytics: dev-zero

Both sources have seven observed days in each week. PostHog recorded 40 sessions, 35 users and 2 conversions in the current week; Search Console recorded 18 clicks and 297 impressions. These are separate populations. Counts increased from zero, but percentage growth is undefined. Current conversion rate is 0.05 and CTR is 0.060606061, both expressed as fractions; neither has a defined previous-week rate. Treat this as observed activity, not evidence of improved acquisition or conversion efficiency.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 0 | 18 | 18 | unknown | count | zero_baseline |
| impressions | 0 | 297 | 297 | unknown | count | zero_baseline |
| position | unknown | 9.19 | unknown | unknown | position | missing |
| ctr | unknown | 0.060606 | unknown | unknown | ratio | missing |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 0 | 40 | 40 | unknown | count | zero_baseline |
| users | 0 | 35 | 35 | unknown | count | zero_baseline |
| conversions | 0 | 2 | 2 | unknown | count | zero_baseline |
| conversion_rate | unknown | 0.05 | unknown | unknown | ratio | missing |

## Findings

- PostHog recorded 2 conversions versus 0 previously, an absolute increase of 2. This establishes observed conversion activity, but the zero baseline leaves percentage growth undefined; it does not establish a sustained improvement. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.
- Search Console recorded 18 clicks versus 0 previously, an absolute increase of 18. Search click activity is now present in the supplied data, but percentage growth is undefined from the zero baseline. These clicks do not establish downstream sessions or conversions. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- Current PostHog conversion rate is 0.05 as a fraction. The previous rate is undefined, so both its absolute and percentage changes are unavailable; the report cannot conclude that conversion efficiency improved. Evidence: posthog.conversion_rate.previous, posthog.conversion_rate.current, posthog.conversion_rate.absolute_change, posthog.conversion_rate.wow_pct.

## Limitations

- This report uses only the supplied synthetic fixture, not live customer data; its observations are not claims about a real business. (synthetic_data)
- Search Console clicks and PostHog sessions represent different populations. They cannot be added, substituted, equated or treated as a linked funnel without attribution evidence. (source_distinction)
- Previous Search Console position is null, so ranking change cannot be assessed even though current position is 9.19. Missing values remain null rather than becoming zero; complete daily coverage does not imply every metric is available. (missing_values)
- Previous impressions and clicks are zero. Previous CTR and all Search Console percentage changes are undefined; absolute click and impression changes remain valid, but CTR and position changes are unavailable. (zero_denominator)
- Previous sessions, users and conversions are zero. Count percentage changes and previous conversion rate are undefined. Absolute count changes remain valid, while conversion-rate changes are unavailable. (zero_denominator)
- Weekly aggregates alone do not establish causes, attribution or sustained trends. The current conversion total is small, so the current rate should not be treated as a stable performance benchmark. (aggregate_scope)

## Next checks

- Before interpreting growth, verify whether each source's prior zero counts reflect genuine inactivity or a change in collection or configuration. Confirm source setup, date filters and metric definitions separately; preserve the supplied zero values unless new evidence warrants correction.
- Review the underlying PostHog conversion events, conversion definition and deduplication alongside session records. Collect another complete week with a nonzero session denominator to establish a comparable conversion-rate baseline.
- Inspect Search Console query and page breakdowns to locate the current impressions and clicks, then compare against another complete week with nonzero impressions. Check position availability separately before asserting a ranking trend.
- If evaluating an organic-search funnel, obtain PostHog acquisition and landing-page attribution and reconcile source scopes, timezones and session definitions before relating Search Console clicks to PostHog outcomes.
