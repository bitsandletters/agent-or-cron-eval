# Weekly analytics: dev-retry

Both sources have complete coverage for both weeks. Search Console shows higher clicks, impressions and CTR alongside a lower average position value. Separately, PostHog shows modest session and user growth, with higher conversion counts and conversion rate. Prioritize investigating the search click increase and whether the conversion improvement persists. These aggregate observations do not establish a shared cause or statistical significance.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 821 | 1067 | 246 | 29.963459 | count | ok |
| impressions | 16423 | 18989 | 2566 | 15.624429 | count | ok |
| position | 7.935 | 7.235 | -0.7 | -8.821676 | position | ok |
| ctr | 0.049991 | 0.05619 | 0.0062 | 12.401385 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1404 | 1474 | 70 | 4.985755 | count | ok |
| users | 1203 | 1244 | 41 | 3.408146 | count | ok |
| conversions | 56 | 63 | 7 | 12.5 | count | ok |
| conversion_rate | 0.039886 | 0.042741 | 0.002855 | 7.157394 | ratio | ok |

## Findings

- Search Console clicks increased from 821 to 1067, an absolute gain of 246 and a 29.963459% week-over-week increase. This is a substantial increase in search click volume; identify which queries and pages account for it before deciding where to focus search work. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- PostHog conversions rose from 56 to 63, an absolute gain of 7 and a 12.5% week-over-week increase. This is an improvement in the recorded conversion count, but the aggregate does not establish conversion value, event validity or a durable trend. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.
- PostHog conversion rate rose from 0.03988604 to 0.042740841 (fractions), with a calculated absolute change of 0.002855 and a 7.157394% relative week-over-week increase. More conversions were recorded per session, but the weekly aggregate cannot distinguish a funnel improvement from a change in session mix or random variation. Evidence: posthog.conversion_rate.previous, posthog.conversion_rate.current, posthog.conversion_rate.absolute_change, posthog.conversion_rate.wow_pct.

## Limitations

- This report uses only the supplied synthetic fixture; it is not evidence about live customers or production performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations. They are neither interchangeable nor additive, and these aggregates do not link search clicks to PostHog conversions. (source_distinction)
- Weekly totals lack query, page, channel, device, funnel and daily breakdowns. They cannot explain causes; a lower aggregate search position value also need not mean every query improved. (aggregate_only)
- The packet supplies no longer-term baseline, session-level outcomes or uncertainty estimates. Conversion increases are descriptive, not proof of statistical significance, revenue growth or sustained improvement. (uncertain_persistence)
- report.json preserves the calculation tool's precision, including fraction-valued rates and its rounded changes. Canonical Markdown tables display at most six decimal places; rate changes should not be recomputed from rounded table cells. (display_precision)

## Next checks

- For a subsequent investigation, break Search Console clicks, impressions, CTR and position down by query and landing page, then device and country. Locate the contributors to click growth and check whether query mix changed before attributing it to ranking or snippet changes.
- Validate the PostHog conversion event definition and deduplication, then compare sessions, conversions and conversion rate within acquisition channels, landing pages, devices and funnel steps. Check segment mix rather than assuming a site-wide funnel improvement or a link to Search Console growth.
- Compare daily patterns and additional complete weeks, and assess conversion-rate uncertainty using appropriate session-level outcomes. Confirm persistence before changing budget or declaring an experiment successful; investigate conversion value separately if business impact is the goal.
