# Weekly analytics: dev-incomplete

Both sources contain incomplete current-week coverage, so week-over-week changes are withheld. Search Console provides partial current clicks and impressions but no current position; PostHog current metrics are missing. No directional weekly change can be concluded from this evidence.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 975 | 585 | unknown | unknown | count | incomplete |
| impressions | 19508 | 11705 | unknown | unknown | count | incomplete |
| position | 6.378 | unknown | unknown | unknown | position | incomplete |
| ctr | 0.049979 | 0.049979 | unknown | unknown | ratio | incomplete |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1729 | unknown | unknown | unknown | count | incomplete |
| users | 1441 | unknown | unknown | unknown | count | incomplete |
| conversions | 86 | unknown | unknown | unknown | count | incomplete |
| conversion_rate | 0.04974 | unknown | unknown | unknown | ratio | incomplete |

## Findings

- Search Console clicks do not support a week-over-week conclusion: current-week coverage is incomplete, so the observed totals should not be interpreted as a change. Evidence: search_console.clicks.wow_pct.
- PostHog sessions cannot be compared week over week because the current value is unavailable and current-week coverage is incomplete; validate ingestion before assessing traffic or conversions. Evidence: posthog.sessions.current, posthog.sessions.wow_pct.
- Search Console position has no current value, preventing a week-over-week position assessment. Evidence: search_console.position.current, search_console.position.wow_pct.

## Limitations

- All inputs are synthetic fixture data; this report does not describe live customer or production performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations and must not be substituted, added, or treated as equivalent. (source_distinction)
- At least one week has fewer than seven observed days; changes are withheld, so weekly Search Console comparisons are not conclusive. (incomplete_data)
- Source metrics contain null values; do not replace them with zero. Current position is unavailable. (missing_values)
- At least one week has fewer than seven observed days; changes are withheld, so weekly PostHog comparisons are not conclusive. (incomplete_data)
- Source metrics contain null values; do not replace them with zero. Current sessions, users, and conversions are unavailable. (missing_values)

## Next checks

- Re-run both source extracts after delayed ingestion has settled and confirm each reporting week has seven observed days.
- Verify Search Console position and PostHog current sessions, users, and conversions are populated before comparing week-over-week KPIs.
- Recalculate CTR from Search Console clicks and impressions, and conversion rate from PostHog conversions and sessions; keep the source populations separate.
