# Weekly analytics: dev-decline

Both sources have complete weekly coverage. Search Console clicks and CTR show the largest relative declines, while average position worsens and impressions fall. Separately, PostHog sessions, users and conversions decline, with conversion rate nearly steady. These aggregate movements do not establish causes or link the populations across sources.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 1535 | 1074 | -461 | -30.032573 | count | ok |
| impressions | 30691 | 28645 | -2046 | -6.666449 | count | ok |
| position | 5.753 | 7.053 | 1.3 | 22.596906 | position | ok |
| ctr | 0.050015 | 0.037493 | -0.012521 | -25.035075 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 2445 | 1956 | -489 | -20 | count | ok |
| users | 2140 | 1742 | -398 | -18.598131 | count | ok |
| conversions | 122 | 98 | -24 | -19.672131 | count | ok |
| conversion_rate | 0.049898 | 0.050102 | 0.000204 | 0.409834 | ratio | ok |

## Findings

- Search Console clicks fell from 1535 to 1074, a weekly change of -30.032573%. This is the largest relative decline among the reported KPIs and the first search-performance movement to investigate. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.wow_pct.
- Search Console CTR fell from 0.050014662 to 0.037493454 as fractions, a relative weekly change of -25.035075%. The lower click share warrants query- and page-level validation; the aggregate ratio alone does not establish a cause. Evidence: search_console.ctr.previous, search_console.ctr.current, search_console.ctr.wow_pct.
- PostHog sessions fell from 2445 to 1956, a weekly change of -20.0%. This is the largest relative decline within PostHog and merits a separate traffic and instrumentation check, not attribution to Search Console movements. Evidence: posthog.sessions.previous, posthog.sessions.current, posthog.sessions.wow_pct.

## Limitations

- This report uses only the supplied synthetic fixture, not live customer data; its movements are not evidence of real customer performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations and must not be substituted, added or equated. CTR is clicks divided by impressions; conversion_rate is conversions divided by sessions. (source_distinction)
- Complete weekly coverage permits the reported comparisons, but aggregate counts cannot establish causes, segment contributions or statistical significance. The calculation tool emitted no warnings. (aggregate_only)

## Next checks

- Request Search Console query and landing-page breakdowns for the same periods; locate the largest click losses and compare CTR, impressions and position within consistent device and country segments before attributing the declines.
- Validate PostHog session and conversion definitions, timezone boundaries and event ingestion for both periods; then compare channel and landing-page breakdowns to locate session and conversion losses without equating sessions to search clicks.
- Review daily source-specific series and additional comparable weeks to distinguish a sustained movement from short-term variation; keep each source's population and rate denominator separate.
