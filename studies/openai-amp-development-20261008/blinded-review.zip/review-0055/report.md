# Weekly analytics: dev-quiet

Both sources have complete weekly coverage. Search Console clicks increased modestly, with higher impressions and CTR and a lower average position. Separately, PostHog sessions, users, and conversions increased, while conversion rate was nearly unchanged. These are descriptive changes in synthetic data, not evidence of causes or statistical significance.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 896 | 932 | 36 | 4.017857 | count | ok |
| impressions | 17923 | 18420 | 497 | 2.772973 | count | ok |
| position | 6.833 | 6.633 | -0.2 | -2.926972 | position | ok |
| ctr | 0.049992 | 0.050597 | 0.000606 | 1.211295 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 1679 | 1729 | 50 | 2.977963 | count | ok |
| users | 1417 | 1448 | 31 | 2.187721 | count | ok |
| conversions | 67 | 69 | 2 | 2.985075 | count | ok |
| conversion_rate | 0.039905 | 0.039907 | 0.000003 | 0.006906 | ratio | ok |

## Findings

- Search Console clicks rose from 896 to 932, an increase of 36 clicks (4.017857% week over week), the largest relative KPI change in this report. Validate which queries and pages contributed before attributing the increase to any intervention. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- PostHog conversions rose from 67 to 69, an increase of 2 conversions (2.985075% week over week). This small absolute gain warrants checking conversion-event validity and a longer history before treating it as a sustained improvement. Evidence: posthog.conversions.previous, posthog.conversions.current, posthog.conversions.absolute_change, posthog.conversions.wow_pct.
- PostHog sessions rose from 1679 to 1729, an increase of 50 sessions (2.977963% week over week). Inspect session definitions and channel-level totals to validate the observed traffic change; these sessions are not interchangeable with Search Console clicks. Evidence: posthog.sessions.previous, posthog.sessions.current, posthog.sessions.absolute_change, posthog.sessions.wow_pct.

## Limitations

- All data come from a synthetic fixture. The report demonstrates weekly arithmetic and reporting, not actual customer or business performance. (synthetic_data)
- Search Console clicks and PostHog sessions measure different populations. They must not be substituted, summed, equated, or used as a combined funnel without separately validated attribution. (source_distinction)
- Complete weekly coverage makes the supplied comparisons calculable, but aggregate totals alone do not establish causes, statistical significance, sustained trends, or segment-level changes. The calculation tool emitted no warnings. (aggregate_evidence)

## Next checks

- For a subsequent analysis, obtain daily Search Console query and page breakdowns for both periods; reconcile clicks and impressions to the weekly totals and examine whether composition changes explain the lower average position.
- Validate PostHog session and conversion-event definitions, reporting timezone, filters, and deduplication across both periods; reconcile daily and channel-level counts to the supplied totals.
- Review additional complete weeks of PostHog sessions, conversions, and conversion rate before interpreting the small conversion gain as sustained improvement; use suitable uncertainty estimates rather than inferring significance from these totals.
