# Weekly analytics: dev-decline

Across the complete seven-day periods, Search Console clicks and CTR declined, while reported average position rose (worsened). PostHog sessions and conversions also declined, but its conversion rate was nearly flat. These are separate source populations and do not establish a cause.

Previous: 2026-09-14 to 2026-09-20
Current: 2026-09-21 to 2026-09-27

## search_console

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| clicks | 1535 | 1074 | -461 | -30.032573 | count | ok |
| impressions | 30691 | 28645 | -2046 | -6.666449 | count | ok |
| position | 5.753 | 7.053 | 1.3 | 22.596906 | position | ok |
| ctr | 0.050015 | 0.037493 | -0.012521 | -25.035075 | ratio | ok |

## posthog

| Metric | Previous | Current | Change | WoW % | Unit | Status |
| --- | ---: | ---: | ---: | ---: | --- | --- |
| sessions | 2445 | 1956 | -489 | -20 | count | ok |
| users | 2140 | 1742 | -398 | -18.598131 | count | ok |
| conversions | 122 | 98 | -24 | -19.672131 | count | ok |
| conversion_rate | 0.049898 | 0.050102 | 0.000204 | 0.409834 | ratio | ok |

## Findings

- Search Console clicks decreased; wow_pct was -30.032573%. Evidence: search_console.clicks.previous, search_console.clicks.current, search_console.clicks.absolute_change, search_console.clicks.wow_pct.
- Search Console CTR decreased; wow_pct was -25.035075%. Evidence: search_console.ctr.previous, search_console.ctr.current, search_console.ctr.absolute_change, search_console.ctr.wow_pct.
- PostHog sessions decreased; wow_pct was -20.0%. This does not measure the same population as Search Console clicks. Evidence: posthog.sessions.previous, posthog.sessions.current, posthog.sessions.absolute_change, posthog.sessions.wow_pct.

## Limitations

- This report uses a synthetic fixture, not live customer or production data; treat the results as an evaluation example, not an operational measurement. (synthetic_data)
- Search Console clicks and PostHog sessions cover different populations and are not interchangeable or additive; their parallel declines do not prove a shared cause. (source_distinction)

## Next checks

- Validate the Search Console decline by segmenting clicks, impressions, CTR, and average position by query, page, device, and country, and compare against the same weekdays.
- Check PostHog event and session instrumentation, property filters, and conversion definitions for consistency across both weeks.
- Compare source-specific daily trends and annotate known releases or tracking changes before investigating possible causes; do not combine clicks and sessions into one total.
